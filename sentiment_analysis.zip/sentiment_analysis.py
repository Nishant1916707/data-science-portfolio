"""
Sentiment Analysis: Amazon reviews, social media posts, news headlines
Pipeline: text -> clean -> VADER polarity (pos/neg/neutral) -> lexicon emotions -> aspects -> trends -> insights
Swap the synthetic generator for your own CSV with columns: date, source, text
"""
import re, random, numpy as np, pandas as pd
import matplotlib.pyplot as plt, seaborn as sns
from collections import Counter
from vaderSentiment.vaderSentiment import SentimentIntensityAnalyzer

random.seed(7); np.random.seed(7)

# ---------- 1. Data (synthetic, product: "Nova X2" smartphone) ----------
ASPECT_PHRASES = {
 "Battery": {"pos": ["The battery easily lasts two days, I love it", "Amazing battery life, charging is fast and reliable"],
             "neg": ["Battery drains terribly fast, really disappointing", "Awful battery, it dies by noon and the phone gets hot"],
             "neu": ["The battery is 5000 mAh", "Battery takes about an hour to charge"]},
 "Camera":  {"pos": ["The camera is stunning, photos look fantastic", "Great camera, night shots are beautiful"],
             "neg": ["Camera is blurry and slow, a letdown", "Terrible low light photos, very frustrating camera"],
             "neu": ["The camera has three lenses", "Camera app has a pro mode"]},
 "Price":   {"pos": ["Excellent value for the price, a great deal", "Cheaper than rivals and still fantastic quality"],
             "neg": ["Way too expensive for what you get, overpriced", "Not worth the price, I feel cheated"],
             "neu": ["The price is $499", "It costs the same as last year's model"]},
 "Screen":  {"pos": ["Gorgeous screen, colors are vivid and smooth", "The display is bright and wonderful"],
             "neg": ["Screen scratches easily and the touch is laggy, awful", "Display flickers, so annoying"],
             "neu": ["The screen is 6.5 inches", "Display refresh rate is 120Hz"]},
 "Support": {"pos": ["Support was helpful and friendly, solved it fast", "Delivery was quick and the seller was great"],
             "neg": ["Customer support was rude and useless, never again", "Delivery was late and the box was damaged, horrible"],
             "neu": ["Support replied in two days", "Delivery took five days"]},
}
SRC_WRAP = {
 "Amazon Review": ["{t}. Would {r} it.", "{t}!", "{t}. Bought it last month."],
 "Social Media":  ["{t} #NovaX2", "ngl {t_l} lol", "{t} @NovaMobile", "{t_l} 😐 #tech"],
 "News":          ["Review: {t}", "Analysts say {t_l}", "Report: {t}"],
}
months = pd.date_range("2025-01-01", periods=12, freq="MS")
rows = []
for mi, m in enumerate(months):
    for _ in range(35):
        src = random.choices(list(SRC_WRAP), [.5, .35, .15])[0]
        asp = random.choices(list(ASPECT_PHRASES), [.28, .22, .18, .14, .18])[0]
        # story: a firmware update in month 7 hurts battery sentiment
        p_pos = .60 if src == "Amazon Review" else .45 if src == "Social Media" else .35
        p_neg = .20 if src == "Amazon Review" else .30 if src == "Social Media" else .25
        if asp == "Battery" and mi >= 6: p_pos, p_neg = .12, .70
        if asp == "Price": p_pos, p_neg = p_pos - .15, p_neg + .15
        k = random.choices(["pos", "neg", "neu"], [p_pos, p_neg, max(0, 1 - p_pos - p_neg)])[0]
        t = random.choice(ASPECT_PHRASES[asp][k])
        text = random.choice(SRC_WRAP[src]).format(t=t, t_l=t[0].lower() + t[1:], r="recommend" if k == "pos" else "not recommend")
        rows.append([m + pd.Timedelta(days=random.randint(0, 27)), src, text])
df = pd.DataFrame(rows, columns=["date", "source", "text"])

# ---------- 2. Cleaning ----------
def clean(t):
    t = re.sub(r"http\S+|@\w+|#", "", t)
    return re.sub(r"\s+", " ", t).strip()
df["clean"] = df.text.map(clean)

# ---------- 3. Polarity with VADER (lexicon + rules) ----------
sia = SentimentIntensityAnalyzer()
df["compound"] = df.clean.map(lambda t: sia.polarity_scores(t)["compound"])
df["sentiment"] = pd.cut(df.compound, [-1.01, -0.05, 0.05, 1.01], labels=["Negative", "Neutral", "Positive"])

# ---------- 4. Emotion detection (compact lexicon, NRC-style) ----------
EMO = {
 "Joy":      "love amazing fantastic great wonderful beautiful gorgeous stunning excellent happy fast vivid bright",
 "Trust":    "reliable helpful friendly quick solved value deal quality",
 "Anger":    "rude useless horrible awful annoying terrible never cheated",
 "Sadness":  "disappointing letdown disappoint",
 "Fear":     "hot dies flickers damaged",
 "Disgust":  "overpriced expensive scratches laggy blurry late",
}
EMO_STEMS = {e: tuple(w.split()) for e, w in EMO.items()}
def emotions(t):
    toks = re.findall(r"[a-z']+", t.lower())
    return [e for e, stems in EMO_STEMS.items() if any(tok.startswith(s) for tok in toks for s in stems)]
df["emotions"] = df.clean.map(emotions)

# ---------- 5. Aspect tagging ----------
ASP_KW = {"Battery": ["battery", "charg"], "Camera": ["camera", "photo"], "Price": ["price", "expensive", "cheaper", "costs", "value"],
          "Screen": ["screen", "display"], "Support": ["support", "delivery", "seller"]}
def aspect(t):
    t = t.lower()
    return next((a for a, ks in ASP_KW.items() if any(k in t for k in ks)), "Other")
df["aspect"] = df.clean.map(aspect)
df["month"] = df.date.dt.to_period("M").dt.to_timestamp()
df.drop(columns="emotions").to_csv("sentiment_results.csv", index=False)

# ---------- 6. Visuals ----------
sns.set_theme(style="whitegrid", font_scale=1.05)
COL = {"Positive": "#4C9F70", "Neutral": "#B8BDC6", "Negative": "#D1495B"}
def tidy(ax): sns.despine(ax=ax, left=True); ax.grid(axis="x", visible=False)

# 1: sentiment mix by source
ct = pd.crosstab(df.source, df.sentiment, normalize="index")[["Positive", "Neutral", "Negative"]] * 100
ct = ct.loc[ct.Positive.sort_values().index]
fig, ax = plt.subplots(figsize=(9, 4.5))
left = np.zeros(len(ct))
for s in ct.columns:
    ax.barh(ct.index, ct[s], left=left, color=COL[s], label=s)
    for i, v in enumerate(ct[s]):
        if v > 6: ax.text(left[i] + v / 2, i, f"{v:.0f}%", ha="center", va="center", color="white", fontweight="bold")
    left += ct[s].values
ax.set_title("Social media runs most negative; news stays most neutral", loc="left", fontsize=15, fontweight="bold")
ax.set_xlabel("Share of texts (%)"); ax.legend(ncol=3, frameon=False, loc="upper center", bbox_to_anchor=(.5, -.2))
tidy(ax); ax.grid(axis="y", visible=False); fig.tight_layout(); fig.savefig("s1_sentiment_by_source.png", dpi=200); plt.close()

# 2: emotions
ec = Counter(e for l in df.emotions for e in l)
ecs = pd.Series(ec).sort_values()
pos_e = {"Joy", "Trust"}
fig, ax = plt.subplots(figsize=(8, 4.5))
ax.barh(ecs.index, ecs.values, color=[COL["Positive"] if e in pos_e else COL["Negative"] for e in ecs.index])
for i, v in enumerate(ecs.values): ax.text(v + 2, i, str(v), va="center", fontweight="bold")
ax.set_title("Joy leads, but anger and disgust are loud", loc="left", fontsize=15, fontweight="bold")
ax.set_xlabel("Texts expressing emotion"); tidy(ax); ax.grid(axis="y", visible=False)
fig.tight_layout(); fig.savefig("s2_emotions.png", dpi=200); plt.close()

# 3: aspect sentiment
asp = df[df.aspect != "Other"].groupby("aspect").compound.mean().sort_values()
fig, ax = plt.subplots(figsize=(8.5, 4.5))
ax.barh(asp.index, asp.values, color=[COL["Negative"] if v < 0 else COL["Positive"] for v in asp.values])
for i, v in enumerate(asp.values): ax.text(v + (.015 if v >= 0 else -.015), i, f"{v:+.2f}", va="center", ha="left" if v >= 0 else "right", fontweight="bold")
ax.axvline(0, color="black", lw=1)
ax.set_title("Support and screen score best; battery is the weak spot", loc="left", fontsize=15, fontweight="bold")
ax.set_xlabel("Average sentiment score (-1 to +1)"); ax.set_xlim(asp.min() - .15, asp.max() + .15)
tidy(ax); ax.grid(axis="y", visible=False); fig.tight_layout(); fig.savefig("s3_aspect_sentiment.png", dpi=200); plt.close()

# 4: trend, battery vs everything else
fig, ax = plt.subplots(figsize=(10.5, 5))
bat = df[df.aspect == "Battery"].groupby("month").compound.mean()
oth = df[df.aspect != "Battery"].groupby("month").compound.mean()
ax.plot(oth.index, oth.values, color="#8A8F98", lw=2.5, label="All other topics")
ax.plot(bat.index, bat.values, color="#D1495B", lw=3, marker="o", label="Battery")
ax.axvline(pd.Timestamp("2025-07-01"), color="black", ls="--", lw=1)
ax.text(pd.Timestamp("2025-07-06"), ax.get_ylim()[1] * .92, "Firmware update", fontsize=10)
ax.axhline(0, color="black", lw=.8)
ax.set_title("Battery sentiment collapsed after the July update", loc="left", fontsize=15, fontweight="bold")
ax.set_ylabel("Average sentiment"); ax.legend(frameon=False, loc="lower left"); tidy(ax)
fig.tight_layout(); fig.savefig("s4_trend.png", dpi=200); plt.close()

# 5: top words, positive vs negative
STOP = set("the a an and is it to of in for was i my this that with but at on so too are be have has not would it's last month bought".split())
def top(sent, n=8):
    toks = [w for t in df[df.sentiment == sent].clean for w in re.findall(r"[a-z]{3,}", t.lower()) if w not in STOP and w not in {"novax", "lol", "ngl", "novamobile", "tech", "recommend", "review", "report", "analysts", "say"}]
    return pd.Series(Counter(toks).most_common(n))
fig, axes = plt.subplots(1, 2, figsize=(11, 4.5))
for ax, s in zip(axes, ["Positive", "Negative"]):
    t = top(s)
    ax.barh([w for w, _ in t][::-1], [c for _, c in t][::-1], color=COL[s])
    ax.set_title(f"Top words: {s}", loc="left", fontweight="bold"); tidy(ax); ax.grid(axis="y", visible=False)
fig.tight_layout(); fig.savefig("s5_top_words.png", dpi=200); plt.close()

# ---------- 7. Numbers for the report ----------
overall = df.sentiment.value_counts(normalize=True).mul(100).round(1)
pre, post = df[(df.aspect == "Battery") & (df.date < "2025-07-01")].compound.mean(), df[(df.aspect == "Battery") & (df.date >= "2025-07-01")].compound.mean()
print("Overall %:\n", overall.to_string()); print("\nBy source:\n", ct.round(1).to_string())
print("\nAspect:\n", asp.round(2).to_string()); print("\nEmotions:", dict(ec)); print(f"\nBattery pre/post: {pre:+.2f} -> {post:+.2f}")
print("\nExamples:"); print(df.groupby("sentiment", observed=True).head(2)[["source", "clean", "compound", "sentiment"]].to_string())
