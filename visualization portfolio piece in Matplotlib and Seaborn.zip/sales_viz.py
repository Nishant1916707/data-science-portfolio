"""
Data Visualization Portfolio Piece
Story: "Where is our growth coming from, and where are we leaking profit?"
Dataset: synthetic retail sales (2024-2025). Swap in your own CSV with the same columns.
"""
import numpy as np, pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns

rng = np.random.default_rng(42)

# ---------- 1. Raw data ----------
months = pd.date_range("2024-01-01", "2025-12-01", freq="MS")
regions = ["North", "South", "East", "West"]
cats = {"Electronics": (0.22, 0.12), "Furniture": (0.30, 0.04),
        "Clothing": (0.45, 0.25), "Grocery": (0.15, 0.08)}   # (base share, margin)
rows = []
for i, m in enumerate(months):
    season = 1 + 0.25 * np.sin((m.month - 3) / 12 * 2 * np.pi) + (0.3 if m.month in (11, 12) else 0)
    for r, rw in zip(regions, [1.3, 0.8, 1.0, 1.15 + 0.015 * i]):
        for c, (share, margin) in cats.items():
            rev = 100000 * share * rw * season * (1 + 0.012 * i) * rng.normal(1, 0.06)
            disc = np.clip(rng.normal(0.18 if c == "Furniture" else 0.08, 0.03), 0, 0.4)
            profit = rev * (margin - disc * 0.5) * rng.normal(1, 0.05)
            rows.append([m, r, c, rev, profit, disc])
df = pd.DataFrame(rows, columns=["month", "region", "category", "revenue", "profit", "discount"])
df["margin"] = df.profit / df.revenue
df.to_csv("sales_data.csv", index=False)

# ---------- 2. Style ----------
sns.set_theme(style="whitegrid", font_scale=1.05)
PAL = {"Electronics": "#2E86AB", "Furniture": "#E4572E", "Clothing": "#76B041", "Grocery": "#F2A541"}
GREY = "#8A8F98"
def clean(ax):
    sns.despine(ax=ax, left=True)
    ax.grid(axis="x", visible=False)

# ---------- Chart 1: revenue trend ----------
fig, ax = plt.subplots(figsize=(11, 5))
m = df.groupby("month").revenue.sum() / 1e6
ax.plot(m.index, m.values, color="#2E86AB", lw=2.5, marker="o", ms=4)
ax.fill_between(m.index, m.values, alpha=0.12, color="#2E86AB")
for yr in (2024, 2025):
    pk = m[m.index.year == yr].idxmax()
    ax.annotate(f"{yr} peak: ${m[pk]:.2f}M", (pk, m[pk]), xytext=(0, 14),
                textcoords="offset points", ha="center", fontweight="bold")
ax.set_title("Revenue is growing, and Q4 drives the year", loc="left", fontsize=15, fontweight="bold")
ax.set_ylabel("Monthly revenue ($M)"); ax.set_xlabel(""); ax.set_ylim(0, m.max() * 1.2)
clean(ax); fig.tight_layout(); fig.savefig("1_revenue_trend.png", dpi=200); plt.close()

# ---------- Chart 2: regional growth ----------
fig, ax = plt.subplots(figsize=(9, 5))
g = df.assign(yr=df.month.dt.year).pivot_table(index="region", columns="yr", values="revenue", aggfunc="sum") / 1e6
g["growth"] = (g[2025] / g[2024] - 1) * 100
g = g.sort_values("growth")
cols = ["#E4572E" if x == g.growth.max() else GREY for x in g.growth]
ax.barh(g.index, g.growth, color=cols)
for y, v in enumerate(g.growth):
    ax.text(v + 0.1, y, f"{v:.1f}%", va="center", fontweight="bold")
ax.set_title("West is growing fastest year-over-year", loc="left", fontsize=15, fontweight="bold")
ax.set_xlabel("Revenue growth 2025 vs 2024 (%)"); ax.set_xlim(0, g.growth.max() * 1.2)
clean(ax); ax.grid(axis="y", visible=False); fig.tight_layout(); fig.savefig("2_regional_growth.png", dpi=200); plt.close()

# ---------- Chart 3: revenue vs margin by category ----------
fig, ax = plt.subplots(figsize=(9, 5.5))
c = df.groupby("category").agg(rev=("revenue", "sum"), prof=("profit", "sum"))
c["margin"] = c.prof / c.rev * 100
for name, r in c.iterrows():
    ax.scatter(r.rev / 1e6, r.margin, s=r.prof / 2e4 + 200, color=PAL[name], alpha=.85, edgecolor="white", lw=2)
    ax.annotate(name, (r.rev / 1e6, r.margin), xytext=(0, 22), textcoords="offset points",
                ha="center", fontweight="bold")
ax.set_title("Furniture sells a lot but loses money", loc="left", fontsize=15, fontweight="bold")
ax.set_xlabel("Total revenue ($M)"); ax.set_ylabel("Profit margin (%)")
ax.set_xlim(c.rev.min() / 1e6 * 0.75, c.rev.max() / 1e6 * 1.2); ax.set_ylim(c.margin.min() - 5, c.margin.max() + 5); ax.axhline(0, color="black", lw=1)
ax.text(.99, .02, "Bubble size = total profit", transform=ax.transAxes, ha="right", color=GREY, fontsize=9)
clean(ax); ax.grid(axis="x", visible=True, alpha=.4); fig.tight_layout(); fig.savefig("3_category_margin.png", dpi=200); plt.close()

# ---------- Chart 4: discount vs margin (the insight) ----------
fig, ax = plt.subplots(figsize=(9, 5.5))
for name, d in df.groupby("category"):
    ax.scatter(d.discount * 100, d.margin * 100, color=PAL[name], alpha=.5, s=22, label=name)
sns.regplot(data=df.assign(d=df.discount * 100, mg=df.margin * 100), x="d", y="mg", scatter=False,
            color="black", line_kws={"lw": 2, "ls": "--"}, ax=ax)
ax.set_title("Every extra point of discount erodes margin", loc="left", fontsize=15, fontweight="bold")
ax.set_xlabel("Average discount (%)"); ax.set_ylabel("Profit margin (%)")
ax.legend(frameon=False, ncol=4, loc="upper center", bbox_to_anchor=(.5, -.15))
clean(ax); fig.tight_layout(); fig.savefig("4_discount_vs_margin.png", dpi=200); plt.close()

# ---------- Chart 5: heatmap ----------
fig, ax = plt.subplots(figsize=(8, 4.5))
h = df.groupby(["region", "category"]).apply(lambda d: d.profit.sum() / d.revenue.sum() * 100, include_groups=False).unstack()
sns.heatmap(h, annot=True, fmt=".1f", cmap="RdYlGn", center=h.values.mean(), cbar_kws={"label": "Margin (%)"},
            linewidths=2, linecolor="white", ax=ax)
ax.set_title("Margin by region and category", loc="left", fontsize=15, fontweight="bold")
ax.set_xlabel(""); ax.set_ylabel(""); fig.tight_layout(); fig.savefig("5_margin_heatmap.png", dpi=200); plt.close()

# ---------- Dashboard ----------
fig = plt.figure(figsize=(16, 10)); gs = fig.add_gridspec(3, 4, height_ratios=[.35, 1.3, 1.3])
tot_rev, tot_prof = df.revenue.sum() / 1e6, df.profit.sum() / 1e6
for i, (lab, val) in enumerate([("Total revenue", f"${tot_rev:.1f}M"), ("Total profit", f"${tot_prof:.1f}M"),
                                ("Overall margin", f"{tot_prof / tot_rev * 100:.1f}%"),
                                ("2025 growth", f"{(g[2025].sum() / g[2024].sum() - 1) * 100:.1f}%")]):
    a = fig.add_subplot(gs[0, i]); a.axis("off")
    a.text(.5, .62, val, ha="center", fontsize=26, fontweight="bold", color="#2E86AB")
    a.text(.5, .15, lab, ha="center", fontsize=12, color=GREY)
a = fig.add_subplot(gs[1, :3]); a.plot(m.index, m.values, color="#2E86AB", lw=2.5); a.fill_between(m.index, m.values, alpha=.12, color="#2E86AB")
a.set_title("Monthly revenue ($M)", loc="left", fontweight="bold"); clean(a)
a = fig.add_subplot(gs[1, 3]); a.barh(g.index, g.growth, color=cols); a.set_title("YoY growth (%)", loc="left", fontweight="bold"); clean(a)
a = fig.add_subplot(gs[2, :2]); a.bar(c.index, c.margin, color=[PAL[k] for k in c.index]); a.set_title("Margin by category (%)", loc="left", fontweight="bold"); clean(a)
a = fig.add_subplot(gs[2, 2:]); sns.heatmap(h, annot=True, fmt=".1f", cmap="RdYlGn", cbar=False, linewidths=2, linecolor="white", ax=a)
a.set_title("Margin: region × category (%)", loc="left", fontweight="bold"); a.set_xlabel(""); a.set_ylabel("")
fig.suptitle("Retail Performance Dashboard, 2024–2025", fontsize=20, fontweight="bold", x=.06, ha="left")
fig.tight_layout(rect=[0, 0, 1, .95]); fig.savefig("dashboard.png", dpi=170); plt.close()

print(c.round(1)); print(g.round(1))
